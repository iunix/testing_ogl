export const MODULE_ID = '5e-ogl-character-sheet';
export var MySettings;
(function (MySettings) {
    MySettings["showIconsOnInventoryList"] = "show-icons-on-inventory-list";
    MySettings["showEquipOnInventoryList"] = "show-equip-on-inventory-list";
    MySettings["expandedLimited"] = "expanded-limited";
})(MySettings || (MySettings = {}));
