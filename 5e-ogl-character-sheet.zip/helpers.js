import { MODULE_ID } from "./constants.js";
export function log(force, ...args) {
    var _a, _b;
    //@ts-ignore
    const shouldLog = force || ((_b = (_a = game.modules.get('_dev-mode')) === null || _a === void 0 ? void 0 : _a.api) === null || _b === void 0 ? void 0 : _b.getPackageDebugValue(MODULE_ID));
    if (shouldLog) {
        console.log(MODULE_ID, '|', ...args);
    }
}
